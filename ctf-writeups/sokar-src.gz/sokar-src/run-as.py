import pty, os
pid, fd = pty.fork()
if pid == 0:
	os.execvp("su", ["su", "bynarr", "-c", "/tmp/test"])
elif pid > 0:
      os.read(fd,1024)
      os.write(fd, "fruity\n")
      os.wait()
      os.close(fd)
